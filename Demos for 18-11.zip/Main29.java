package batch1;

import java.util.StringTokenizer;

public class Main29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="Hello We@are &working!with*java%strings";
		
		String ar[]=str.split("@");
		
		for(String s:ar)
		{
			System.out.println(s);
		}
		//to split on the basis of multiple delimiters
		//token=element
		StringTokenizer st=new StringTokenizer(str," @&*!%");
		
		System.out.println("Count Of Tokens : "+st.countTokens());
		while(st.hasMoreTokens())
		{
			System.out.println(st.nextToken());
		}
		System.out.println("Count Of Tokens : "+st.countTokens());
		
	}

}
