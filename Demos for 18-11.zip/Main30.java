package batch1;

public class Main30 {

	public static void main(String[] args) {
//StringBuffer - Thread Safe
		
//		StringBuffer str1=new StringBuffer();//creating an instance with a default capacity of 16
//		StringBuffer str2=new StringBuffer();//instance of stringbuffer with specified string
//		StringBuffer str3=new StringBuffer(20);//initial capacity
//		
//		//new capacity=oldcapacity*2+2;
//		System.out.println("str1 : "+str1.capacity());
//		System.out.println("str2 : "+str2.capacity());
//		System.out.println("str3 : "+str3.capacity());
//		
//		str1.append(" Programmers.How");//16
//		System.out.println("str1 : "+str1.capacity());
//		str1.append(" is the experience");//18
//		System.out.println(str1);
//		System.out.println("str1 : "+str1.capacity());
//		str1.append(" of learning java programming");//29
//		System.out.println(str1);	
//		System.out.println("str1 : "+str1.capacity());
//		
//		str2.append("Programmers.How is the experience of learning");//45
//		System.out.println("str2 count : "+str2.length());
//		System.out.println("str2 : "+str2.capacity());
//		str2.append(" java language");//
//		System.out.println("str2 count : "+str2.length());//58
//		System.out.println("str2 : "+str2.capacity());
//		
		//palindrome
		//malayalam
		//malayalam
		//12321 :12321
		
		String str = "Aditya", reverseStr = "";
	    
	    int strLength = str.length();

	    for (int i = (strLength - 1); i >=0; --i) {
	      reverseStr = reverseStr + str.charAt(i);
	    }

	    if (str.toLowerCase().equals(reverseStr.toLowerCase())) {
	      System.out.println(str + " is a Palindrome String.");
	    }
	    else {
	      System.out.println(str + " is not a Palindrome String.");
	    }	
	    
	    
	    String st43r="frjkjfr";//SCP
	    String str798=new String("fhsjh");//Heap Area
	    StringBuffer ref1=new StringBuffer("MALAYALAM");//Heap Area
	    if(ref1.equals(ref1.reverse()))
	    {
	    	System.out.println("Palindrome");
	    }
	    else
	    {
	    	System.out.println("Not a palindrome");
	    }
	    ref1.delete(0, 3);
	    System.out.println(ref1);
	    
	    ref1.ensureCapacity(200);
	    System.out.println(ref1.capacity());
	    //150 50
	  //  ref1.append("kghejrk gkrejhgkjre grkegkrjeg rgrekjgr jmgkrghkjreg rjgjreg m gkjreg ");
	    System.out.println(ref1.length());
	    ref1.trimToSize();
	    System.out.println(ref1.capacity());
	    System.out.println(ref1);
	    ref1.insert(0,"Welcome ");
	    System.out.println(ref1);
	    ref1.replace(7, 9, " MALA");
	    System.out.println(ref1);
	    System.out.println(ref1.substring(1, 9));
	    System.out.println(ref1.indexOf("e"));
	    System.out.println(ref1.lastIndexOf("e"));
	    System.out.println(ref1.indexOf("e",5));//from 5th to last
	    System.out.println(ref1.lastIndexOf("e",10));// from first to 10th
	    //indexOf method works in the forward direction
	    //lastIndexOf works in the backward direction
	    
	    
	    //StringBuilder
	    //enum
	    //questions on hackerearth or hackerrank
	    //5 questions 
	    
	    
	    
	    
	    
	    
	}

}


