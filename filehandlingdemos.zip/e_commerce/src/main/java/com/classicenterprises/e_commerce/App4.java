package com.classicenterprises.e_commerce;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class App4 {

	public static void main(String[] args) {
		
		deserializationCode();
		
	}
	
	static void serializationCode()
	{
		try
		{
			FileOutputStream fout=new FileOutputStream("C:\\Users\\hp\\OneDrive\\Desktop\\objectInfo.txt");
			StudentInformation studentInformation=new StudentInformation(1,"Jatin",24);
			StudentInformation studentInformation1=new StudentInformation(2,"Priyansh",21);
			
			ObjectOutputStream oos=new ObjectOutputStream(fout);
			ArrayList<StudentInformation> al=new ArrayList<>();
			al.add(studentInformation);
			al.add(studentInformation1);
			
			oos.writeObject(al);
			oos.close();
			fout.close();
			System.out.println("Serialization achieved");
		}
		catch(Exception e)
		{	
			e.printStackTrace();
		}
	}
	
	static void deserializationCode()
	{
		try
		{
			FileInputStream fout=new FileInputStream("C:\\Users\\hp\\OneDrive\\Desktop\\objectInfo.txt");
			ObjectInputStream oos=new ObjectInputStream(fout);
			ArrayList<StudentInformation> st=(ArrayList<StudentInformation>)oos.readObject();
			for(StudentInformation s1:st)
			{
				System.out.println(s1.studentId+" "+s1.studentName+" "+s1.age);
			}
			oos.close();
			fout.close();
		}
		catch(Exception e)
		{
			
		}
	}
	
}

class StudentInformation implements Serializable//marker interface
{
	transient int studentId;
	String studentName;
	int age;
	public StudentInformation(int studentId, String studentName, int age) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.age=age;
	}	
}