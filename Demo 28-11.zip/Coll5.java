package demox;

import java.util.TreeSet;

public class Coll5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//TreeSet
		//duplicacy is not allowed
		//dynamically growable
		//as it implements SortedSet interface
		//it arranges the elements in sorted/ascending order
		
		
		TreeSet<String> ts=new TreeSet<>();
		
		ts.add("Nisha");
		ts.add("Rahul");
		ts.add("Shivansh");
		ts.add("Hridyaa");
		ts.add("Avikshit");
		
		System.out.println(ts);
		System.out.println(ts.size());
		System.out.println(ts.first());
		System.out.println(ts.last());
		
		System.out.println(ts.pollFirst());
		System.out.println(ts.pollLast());
		System.out.println(ts.remove("Nisha"));
		System.out.println(ts);
		
		TreeSet<Integer> ts1=new TreeSet<>();
		
		ts1.add(123);
		ts1.add(32);
		ts1.add(189);
		ts1.add(20);
		ts1.add(90);
		ts1.add(892);
		ts1.add(627);
		ts1.add(45);
		ts1.add(900);
		System.out.println(ts1);
		System.out.println(ts1.ceiling(45));
		System.out.println(ts1.floor(45));
	}

}
