package com.jdbcprojectbatch1;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.Types;
import java.sql.CallableStatement;
public class CallableProcedure1 
{
    public static void main( String[] args )
    {
    	try
    	{
    		//Register the driver
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		//Create the connection
    		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch18103?useSSL=false&autoReconnect=true","root", "root");
    		//create the query
    		String query="{CALL EMP_COUNT(?,?)}";
    		CallableStatement stmt=con.prepareCall(query);
    		stmt.setInt(1, 22);
    		stmt.registerOutParameter(2, Types.INTEGER);
    		//execute the query
    		
    		if(stmt.execute())
    		{
    			System.out.println("Updated data successfully");
    		}
    		else
    		{
    			System.out.println("Not able to update");
    		}
    		
    		
    		int i=stmt.executeUpdate();
    		if(i>0)
    		{
    			System.out.println("Updated data successfully");
    		}
    		else
    		{
    			System.out.println("Not able to update");
    		}
    		System.out.println(stmt.getInt(2));
    		//close the connection
    		stmt.close();
    		con.close();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		System.out.println(e);
    	}
    }
}
