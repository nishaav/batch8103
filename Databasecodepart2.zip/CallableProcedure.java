package com.jdbcprojectbatch1;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.CallableStatement;
public class CallableProcedure 
{
    public static void main( String[] args )
    {
    	try
    	{
    		//Register the driver
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		//Create the connection
    		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch18103?useSSL=false&autoReconnect=true","root", "root");
    		//create the query
    		String query="{call EMP_INFO}";
    		CallableStatement stmt=con.prepareCall(query);
    		//execute the query
    		stmt.execute();// for out mode parameter as a response
    		ResultSet rs=stmt.executeQuery();// for select query that responds a table or multiple records
    		while(rs.next())
    		{
    			System.out.println("Name : "+rs.getString("empName")+" Id : "+rs.getInt(1)+" Age : "+rs.getInt("empAge")+" Contact : "+rs.getString(4)+" Email : "+rs.getString(5));
    		}
    		//close the connection
    		rs.close();
    		stmt.close();
    		con.close();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		System.out.println(e);
    	}
    }
}
