package com.classicenterprises.DesignPatterns;
//facade design pattern : deals with hiding the complexity and providing 1 interface to the client to 
//access the required functionality.
//abstraction is performed.
public class Facade 
{
	public static void main(String[] args) 
	{
			ShapeImpl shapeImpl=new ShapeImpl();
			shapeImpl.drawCircle();
			shapeImpl.drawSquare();
			shapeImpl.drawTriangle();
	}
}
//interface
interface Shape
{
	void draw();
}
//implementing classes
class Circle implements Shape
{
	public void draw()
	{
		System.out.println("Drawing Circle");
	}
	
}

class Square implements Shape
{
	public void draw()
	{
		System.out.println("Drawing Square");
	}
}

class Triangle implements Shape
{
	public void draw()
	{
		System.out.println("Drawing Triangle");
	}
}
//Facade class
class ShapeImpl 
{
	//aggregation
	private Circle c;
	private Square s;
	private Triangle t;
	public ShapeImpl() {
		this.c = new Circle();
		this.s = new Square();
		this.t = new Triangle();
	}
	public void drawCircle()
	{
		c.draw();
	}
	public void drawSquare()
	{
		s.draw();
	}
	public void drawTriangle()
	{
		t.draw();
	}
	
	
}
