package com.classicenterprises.DesignPatterns;

public class DecoratorDesignPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Car car1=new Era(new Eon());
			car1.display();
			Car car2=new EraPlus(new EonPlus());
			car2.display();		
	}

}
//Component Interface
interface Car
{
	void display();
}
//Component Implementation
class Eon implements Car
{
	public void display()
	{
		System.out.println("diplaying info about Eon Era+");
	}
}
class EonPlus implements Car
{
	public void display()
	{
		System.out.println("diplaying info about EonPlus Era+");
	}
}

//Decorator
class CarDecorator implements Car
{
	Car car;//HAS-A Relationship
	CarDecorator(Car car)
	{
		this.car=car;
	}
	public void display()
	{
		this.car.display();
	}
}
//Concrete Decorators : accessing the decorator and modyfying the functionality
class EraPlus extends CarDecorator
{
	EraPlus(Car car)
	{
		super(car);
	}
	public void display()
	{
		super.display();
		System.out.println("Information Displayed about EraPlus");
	}
}
//Concrete Decorators : accessing the decorator and modyfying the functionality

class Era extends CarDecorator
{
	Era(Car car)
	{
		super(car);
	}
	public void display()
	{
		super.display();
		System.out.println("Information Displayed about Era");
	}
}

