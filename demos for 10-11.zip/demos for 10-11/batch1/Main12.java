package batch1;

public class Main12 {

	public static void main(String args[])
	{
		
	}
}
/*
 * 
 * private->default->protected->public
 * 
 * private : within the class
 * default : within the class
 * 			outside the class 
 * protected : within the class
 * 				outside the class
 * 					outside the program
 * 					outside the package (through inheritance)
 * 	
 * public : within the class
 * 				outside the class
 * 					outside the program
 * 					outside the package
 * 						
 * demos for visibility 
 * 
 * 
 * method creation
 * method calling
 * object creation
 * constructor : default and parameterised
 * static  : with method and variables
 * 
 * 
 * 
 * 
 * least-->most
 * 
 */ 
