package batch1;

import demo.Permission3;
import demo.Permission4;

public class Main13 extends Permission3{

	void display()
	{
		name="Java";
		System.out.println(name);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Main13 main13=new Main13();
//	main13.display();
//	
//	Permission4 permission4=new Permission4("Java",34);
//	System.out.println(permission4.data);
//	System.out.println(permission4.value);
		
		Dummy dummy=new Dummy();
		dummy.disp();
		dummy.display();
		dummy.show();
	}
}

class Car
{
	private int num1=10;
	protected int num2=20;
	void display()
	{
		System.out.println(num1);
		System.out.println("Working with Car class");
	}
}
class Maruti extends Car
{
	void show()
	{
		System.out.println("Provide description of Maruti ");
	}
}
class Dummy extends Maruti
{
	int num2=30;
	void disp()
	{
		int num2=90;//local variable
		System.out.println(num2);//local
		System.out.println(this.num2);//current class
		System.out.println(super.num2);//parent class
	//	System.out.println(num1);
		
		System.out.println("End of program!!");
	}
}
