package demo;

public class Permission3 {

	protected String name;
	
	
}
