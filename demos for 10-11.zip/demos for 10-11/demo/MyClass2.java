package demo;

public class MyClass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Permission2 permission2=new Permission2();
			System.out.println(permission2.name);
	}
}
