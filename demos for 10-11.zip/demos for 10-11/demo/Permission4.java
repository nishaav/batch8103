package demo;

public class Permission4 {
	public String data;
	public int value;
	
	public Permission4(String data, int value) {
		this.data = data;
		this.value = value;
	}
	
	
	
}
