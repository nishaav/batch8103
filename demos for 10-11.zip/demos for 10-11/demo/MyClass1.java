package demo;

import java.util.Scanner;

public class MyClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		Permission permission=new Permission();
		permission.show();
		
		Permission2 permission2=new Permission2();
		System.out.println(permission2.name);
	}

}
/*
 * access modifiers :
 * 1)private
 * 2)default
 * 3)protected
 * 4)public
 * 
 * scale of accessibility :
 * private>default>protected>public
 * 
 * error : weaker access privilege
 * 
 * Access modifier    within class     within package     outside package by child    outside package
 * 
 * private				Y					N					N							N
 * default				Y					Y					N							N
 * protected			Y					Y					Y							N
 * public				Y					Y					Y							Y
 * 
 * class : default or public
 * private and protected modifiers can not be used with outer classes 
*/
class Permission
{
	private int num1;
	String name;
	float var;
	char ch;
	double d;
	void show()
	{
		System.out.println("[int:"+num1+"],[string:"+name+"],[float:"+var+"],[char:"+ch+"],[double:"+d+"]");
	}
}	


class Permission2
{
	String name;	
}