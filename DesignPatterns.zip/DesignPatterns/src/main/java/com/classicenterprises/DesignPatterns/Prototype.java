package com.classicenterprises.DesignPatterns;

public class Prototype {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp=new Employee(1,"Jatin");
		emp.show();
		
		Employee emp2=(Employee)emp.getClone();
		emp2.show();
		
		
	
	}
}

interface Dummy
{
	public Dummy getClone();
}

class Employee implements Dummy
{
	private int id;
	private String name;
	
	public Employee(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	
	public void show()
	{
		System.out.println("Id : "+id+" Name : "+name);
	}

	public Dummy getClone()//creating a copy 
	{
		return new Employee(id,name);
	}
}

//avoids multiple object creation hence saves memory.