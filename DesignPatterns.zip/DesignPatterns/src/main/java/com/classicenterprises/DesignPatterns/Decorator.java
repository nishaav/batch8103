package com.classicenterprises.DesignPatterns;
//structural design pattern
public class Decorator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}



interface Demo
{
	public String getDetails();
	public int getCosting();
}
class DemoChild implements Demo
{
	public String getDetails()
	{
		return "Details provided";
	}
	public int getCosting()
	{
		return 100;
	}
}
//association and composition
abstract class DemoChild2 implements Demo
{
	private Demo demo;
	DemoChild2(Demo demo)
	{
		this.demo=demo;
	}
	@Override
	public String getDetails() {
		// TODO Auto-generated method stub
		return demo.getDetails();
	}
	@Override
	public int getCosting() {
		// TODO Auto-generated method stub
	return demo.getCosting(); 
	}	
}
class DemoChild3 extends DemoChild2
{

	DemoChild3(Demo demo) {
		super(demo);
		// TODO Auto-generated constructor stub
	}
	
	public String getDetails()
	{
		return super.getDetails()+" in child class";
	}
	public int getCosting()
	{
		return super.getCosting()+100;
	}
	
}
class DemoChild4 extends DemoChild2
{

	DemoChild4(Demo demo) {
		super(demo);
		// TODO Auto-generated constructor stub
	}
	
	public String getDetails()
	{
		return super.getDetails()+" in child class";
	}
	public int getCosting()
	{
		return super.getCosting()+100;
	}
	
}