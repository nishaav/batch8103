package com.classicenterprises.DesignPatterns;

public class Singleton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Singleton1 single=Singleton1.getSingleton1();
		single.show();
	}

}

class Singleton1
{
	private static Singleton1 singleton1=new Singleton1();
	private Singleton1()
	{
		
	}
	public static Singleton1 getSingleton1()
	{
		return singleton1;
	}
	
	public void show()
	{
		System.out.println("Show method of Singleton1 class");
	}

	
}