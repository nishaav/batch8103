package com.classicenterprises.DesignPatterns;

import java.util.Scanner;

/**
 * Hello world!
 *	CREATIONAL DESIGN PATTERN
 * Factory Method Pattern or Factory Pattern or Factory Design Pattern
 *
 */

abstract class Billing
{
	double roi;
	abstract void getRoi();
	public void getCost(int units)
	{
		System.out.println(units*roi);
	}
}

class DomesticBilling extends Billing
{
	void getRoi()
	{
		roi=4;
	}
}

class CommercialBilling extends Billing
{
	void getRoi()
	{
		roi=6;
	}
}
//Billing billing=new DomesticBilling();
//Billing billing=new CommercialBilling();
class GetBillingObject
{
	public Billing getInstance(String type)
	{
		if(type==null)
		{
			return null;
		}
		else if(type.equalsIgnoreCase("domestic"))
		 {
			 return new DomesticBilling();
		 }
		else if(type.equalsIgnoreCase("Commercial"))
		 {
			 return new CommercialBilling();
		 }
		else
		{
			return null;
		}
	}
}
//loose coupling
public class App 
{
    public static void main( String[] args )
    {
    	GetBillingObject gbo=new GetBillingObject();
    	Scanner scanner=new Scanner(System.in);
        System.out.println( "Name of plan : " );
        String planName=scanner.nextLine();
        Billing billing=gbo.getInstance(planName);//loose coupling
        System.out.println("No. Of units : ");
        int units=scanner.nextInt();
        billing.getRoi();
        billing.getCost(units);
    }
}
/*
 * 
 *When to implement factory method pattern
 *1) when we are not sure which class instance to be created.
 *2) when parent class decides the creation of object to its subclasses.
 *     indirectly we are applying upcasting
 * 
 * 
 *
*/