package com.jdbcprojectbatch1;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.util.Scanner;
public class App 
{
    public static void main( String[] args )
    {
    	try
    	{
    		//https://www.facebook.com/contact
    		//Register the driver
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		//Create the connection
    		//DriverManager.getConnection(url, username, password);
    		//3306(default),3307,3308,3309
    		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch18103?useSSL=false&autoReconnect=true","root", "root");
    		Scanner scanner=new Scanner(System.in);
    		System.out.println("Enter the details : ");
    		System.out.print("Name : ");
    		String name=scanner.nextLine().trim();
    		System.out.print("Age : ");
    		int age=scanner.nextInt();
    		scanner.nextLine();
    		System.out.print("Contact : ");
    		String contact=scanner.nextLine().trim();
    		System.out.print("Email : ");
    		String email=scanner.nextLine().trim();
    		//create the query
    		//insert,update,delete : PreparedStatement : interfaces as it cannot return data can only return whether query
    		//is executing or not
    		//Select : Statement interfaces
    		//can return data fetched from the table    		
    		//insert into emp(empAge,empName,empContact,email) values(?,?,?,?);
    		//String query2="insert into emp values(8,'"+name+"',"+age+",'"+contact+"','"+email+"')";
    		String query="insert into emp values(?,?,?,?,?)";
    		PreparedStatement ps=con.prepareStatement(query);
    		ps.setInt(1, 8);
    		ps.setString(2, name);
    		ps.setInt(3,age);
    		ps.setString(4, contact);
    		ps.setString(5,email);
    		//execute the query
    		int count=ps.executeUpdate();
    		if(count>0)
    		{
    			System.out.println("Data inserted successfully");
    		}
    		else
    		{
    			System.out.println("Unable to execute the query");
    		}
    		//close the connection
    		ps.close();
    		con.close();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		System.out.println(e);
    	}
    }
}
