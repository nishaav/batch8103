package batch1;
//toString method
public class Main20 {
	String name;
	Main20(String name)
	{
		this.name=name;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main20 main=new Main20("Java");
		System.out.println(main);
		
		String str=new String("Java");
		System.out.println(str);
	}
	public Integer toInteger()
	{
		return 0;
	}
	public String toString()
	{
		System.out.println("Hello");
		return "Welcome "+name;
	}
}
/*
 * Task for the day : 
 * Abstraction 
 * ->abstract classes
 * ->interfaces
 */

