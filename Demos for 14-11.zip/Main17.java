package batch1;

public class Main17 {

	public static void main(String args[])
	{
		Eclipse eclipse=new Eclipse();
		eclipse.show();
		eclipse.show(10, 20);
		eclipse.show(23, 34);
		eclipse.show(34.5f, 45.6f);
	}
}
/*
 * If a class has multiple methods having same name but different in parameters, it is known as Method Overloading.
 */
//method overloading
class Eclipse
{
	void show()
	{
		System.out.println("Welcome Users!!");
	}
	void show(int a,int b)
	{
		System.out.println("The output of addition is "+(a+b));
	}
	void show(String a,String b)
	{
		System.out.println("The combination is "+(a+b));
	}
	void show(float a,float b)
	{
		System.out.println("The float addition is "+(a+b));
	}
//	int show(double a,double b)//covariant type
//	{
//		System.out.println("The double addition is "+(a+b));
//		return 0;
//	}
//	void show(double a,double b)//covariant type
//	{
//		System.out.println("The double addition is "+(a+b));
//	}
}


//Polymorphism
//Poly + Morphos
//many + forms
//multiple forms of a single entity
//human being : 
//student/learner
//child
//friend
//

//overloading : static polymorphism
// creating multiple forms
// change the structure 
// for methods
//int add(int a,int b)
//{
//	
//}
// for constructor

//overriding : dynamic polymorphism
//it can be performed between parent and child class
//we can change the definition not declaration

//int add(int a,int b)
//{
//	
//}
//

//final
//1.5 const :
/*
 * final :
 * keyword used to add restrictions
 * 
 *  1) variable : to make constant
 *  2) methods : to avoid overriding
 *  3) class : to avoid inheritance
 *  
 * 
 *
 */

