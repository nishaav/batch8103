package batch1;

public class Main19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dummy2 dummy2=new Dummy2();
		dummy2.add(12, 23);
		dummy2.div();
		
		Dummy12 dummy=new Dummy12();
		dummy.add(34, 46);	
		

		Dummy12 dummyRef=new Dummy2();//dynamic method dispatching or upcasting
		dummyRef.add(23, 45);
		dummyRef.sub();
		//dummyRef.div();
		//only those methods will be called which have there existence in parent class.
		//overridden definition will be getting more priority.
	}
}
class Dummy12
{
	void add(int a,int b)
	{
		System.out.println(a+b);
	}
	void sub()
	{
		System.out.println("Hello");
	}

}

class Dummy2 extends Dummy12
{
	void add(int a,int b)
	{
		System.out.println("The output of addition is ");
		System.out.println(a+b);
	}
	void sub()
	{
		System.out.println("Hello Learners");
	}
	void div()
	{
		System.out.println("Division");
	}
}
//overriding
/*
 * Overriding is also known as runtime polymorphism or dynamic polymorphism
 * It can be performed amongst parent and child classes
 * As per overriding, one can change the method definition by carrying a same declaration
 * It can be performed with methods only.
 * 
 * 
 * 
 */
