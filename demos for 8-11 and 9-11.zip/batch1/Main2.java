package batch1;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * C O B O L
		 * C O B O
		 * C O B
		 * C O 
		 * C
		 * 
		 * 
		 * 
		 * 1
		 * 1 3 
		 * 1 3 5
		 * 1 3 5 7
		 * 1 3 5 7 9
		 * 
		 */

		for(int i=1;i<=9;i+=2)
		{
			for(int j=1;j<=i;j+=2)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}
		
//		char ch[]= {'C','O','B','O','L'};//char type array
//		
//		for(int i=ch.length-1;i>=0;i--)//row
//		{
//			for(int j=0;j<=i;j++)//columns
//			{
//				System.out.print(ch[j]);
//			}
//			System.out.println();
//		}
//		
		
			
	}

}
