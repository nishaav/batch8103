package batch1;

public class Main8 
{
	public static void main(String[] args) 
	{
		Student student=new Student(6);
	}
}
class Student
{
	Student(int b)//default
	{
		System.out.println("Welcome User!!");
	}
	int add()
	{
		return 0;
	}
	int sub()
	{
		return 0;
	}
	int multiple()
	{
		return 0;
	}
}

/*
 *Constructor : 
 *
 * ->special methods of a class
 * ->they do not have a return type
 * ->called automatically whenever the instance of a class is created.
 * ->constructors are named as class name
 * 
 * two types :
 * default : auto created
 * 
 * parameterised : to be created by the user as per the requirement
 * 
 * in case user is creating a constructor for the class, then default will not be created.
 * 
 * purpose of constructor :
 * 1) create the object 
 * 2) to set the values for member variables of the class.
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
