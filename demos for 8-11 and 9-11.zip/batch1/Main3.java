package batch1;

import java.util.Scanner;

public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//searching 
		//linear search & binary search
		
		//23 4 123 54 234 54 76 87 98 9 100
		//best case average worst
		//linear search
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the size of array : ");
		int n=scanner.nextInt();
		
		System.out.println("Enter "+n+" elements : ");
		
		int ar[]=new int[n];
		for(int i=0;i<n;i++)
		{
			ar[i]=scanner.nextInt();
		}
		
		System.out.println("Enter the number to be searched : ");
		int search=scanner.nextInt();
		int pos=0;
		int count=0;
		for(int i=0;i<n;i++)
		{
			if(ar[i]==search)
			{
				count++;
				pos=i;
				break;
			}
		}
		if(count==1)
		{
			System.out.println("The element "+search+" found at "+(pos+1)+" position");
			
		}
		else
		{
			System.out.println("The element "+search+" not found");

		}
		
		
		
	}

}
