package batch1;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10,b=20;
//a=20,b=10
System.out.println("Values before swapping");
System.out.println("a : "+a+" b : "+b);
//option 1 :
int c=a;
a=b;
b=c;
System.out.println("Values after swapping");
System.out.println("a : "+a+" b : "+b);

//option 2 :

int x=10,y=20;
System.out.println("Values before swapping");
System.out.println("x : "+x+" y : "+y);

x=x+y;//x=30;
y=x-y;//y=30-20=>y=10
x=x-y;//x=30-10=>x=20
System.out.println("Values after swapping");
System.out.println("x : "+x+" y : "+y);


//swapping : changing the values of two operands with each other
//sorting : arranging the bunch of elements in increasing / decreasing order or ascending / descending order

	}

}
