package batch1;

import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
//		Scanner s=new Scanner(System.in);
//		s.nextInt();
		Main6 main=new Main6();
		//ClassName referencevariablename=new ClassName();
		//new : dynamic memory allocator
		
		main.demo();
		demo1();
		User.show();//classname as a reference
		User user=new User();
		user.display();
		//location
		
	}
	public void demo()
	{
		System.out.println("Hello User");
	}
	public static void demo1()
	{
		System.out.println("Hello User");
	}
}
class User
{
	static void show()
	{
		System.out.println("Static method");
	}
	void display()
	{
		System.out.println("Non-static method");
	}
}






/*
 * 
 * Java : OOPs
 * methods : executable block of code
 * pre defined
 * user defined 
 * 
 * static returntype methodname()
 * {
 * 
 * }
 * 
 * 
 * 
 *
 */


