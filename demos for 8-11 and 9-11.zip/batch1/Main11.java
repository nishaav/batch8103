package batch1;

public class Main11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bridge bridge=new Bridge();
		bridge.demo();
	}
}

class Edu
{
	private void show()
	{
		System.out.println("Works well!!");
	}
	void demo()
	{
		show();//reflection
		System.out.println("Works well enough!!");
	}
}
class Bridge extends Edu
{
	
}

/*
 *Inheritance :
 *
 *Inheriting(accessing) the properties of parent into the child classes.
 *
 *->private properties of parent cannot be accessed by the child class.
 *Inheritance depicts 'IS-A' relationship among classes.
 *types of inheritance
 *1)Single-level : A->B
 *2)Multi-level : A->B->C
 *3)Hierarchial : A->B,C (inverted-tree like structure)
 * 
 * ->extends keyword is used to do inheritance
 * 
 * ->default inheritance
 *
 * child class can have only 1 parent class
 * 
 * Object class is inherited automatically by the other java classes
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
