package batch1;

public class Main10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User1 user1=new User1();
		user1.show();
		User1 user2=new User1();
		user2.show();
		User1 user3=new User1();
		user3.show();
		User1 user4=new User1();
		user4.show();
		user1.show();
	}
}
class User1
{
	int a=1;
	static int b=1;
	
	User1()
	{
		a++;
		b++;
	}
	void show()
	{
		System.out.println("a : "+a+" b : "+b);
	}
}