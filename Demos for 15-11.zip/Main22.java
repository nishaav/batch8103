package batch1;

public class Main22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B89 b=new B89();
		b.display();
		b.show();	
		b.disp();
	
		A89 a=new B89();
		a.display();
		a.show();	
		
		
	}
}
abstract class A89
{
	void display()//non-abstract method
	{
		System.out.println("Non-abstract method");
	}
	abstract void show();
}
class B89 extends A89
{
	 void show()
	 {
		 System.out.println("Definition for the abstract method");
	 }
	 void disp()
	 {
		 System.out.println("Disp of child class");
	 }
}