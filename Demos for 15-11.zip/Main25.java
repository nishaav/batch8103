package batch1;

public class Main25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//anonymous class : class without any name
		//anonymous interface : 
		Ir1 ir1=new Ir1() {
			
			public void show()
			{
				System.out.println("Definition for the show method of Ir1");
			}
			public void disp()
			{
				System.out.println("Definition for the disp method of Ir1");
			}
		};
		
		Ir2 ir2=new Ir2()
				{
					public void show()
					{
						System.out.println("Definition for the show method of Ir2");
					}
				};
				ir1.disp();
				ir1.show();
				ir2.show();
	}

}
interface Ir1
{
	void show();
	void disp();
}
interface Ir2
{
	void show();
}