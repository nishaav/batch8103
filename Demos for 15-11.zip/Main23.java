package batch1;

public class Main23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AC2 ac=new AC2();
		ac.show();
	}

}
abstract class CA1
{
	
}
interface I1
{
	int a=10;
	void show();
}
interface I2
{
	void disp();
}
abstract class AC1 implements I1,I2
{
	
}
class AC2 extends AC1
{
	public void show() {
		System.out.println(a);
		System.out.println("Writing the code");
	}	
	public void disp()
	{
		System.out.println("Definition to the method of I2");
	}
	
}

interface I3 extends I1,I2
{
	
}
/*
 * interface can inherit more than one interface
 * class can inherit one class
 * class can implement more than one interface
 *
 */


