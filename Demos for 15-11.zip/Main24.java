package batch1;

public class Main24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D1 d1=new D3();
		d1.show();
		D2 d2=new D3();
		//d2.show();
	}

}
interface D1
{
	void show();
}
interface D2
{
	int show(int a);
}
class D3 implements D1,D2
{
	
	@Override
	public void show() {
		// TODO Auto-generated method stub
	System.out.println("Show method defined");	
	}
	@Override
	public int show(int a) {
		// TODO Auto-generated method stub
	System.out.println("Show method defined");	
	return 0;
	}
	
}