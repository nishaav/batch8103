package batch1;

public class Main21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A2 a2=new A2();
		a2.disp();
		a2.display();
		a2.show();

		A1 a1=new A2();//upcasting
		a1.display();
		a1.show();
		//a1.disp();
		
	}

}
interface A1
{
	void show();	
	default void display()//java 8
	{
		System.out.println("Default Keyword");
	}
}
class A2 implements A1
{
	public void show()
	{
		System.out.println("Hello Learner");
	}
	public void disp()
	{
		System.out.println("Default functionality");
	}
}
