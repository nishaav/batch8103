package batch1;

public class Main26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		S1 s1=new S1(7);
//		S1.S2 s2=s1.new S2(14);
//		s2.show();
//		S1.S3 s3=s1.new S3();

		
//		java.util.Scanner sc=new java.util.Scanner(System.in);//fully qualified name
//		
//		Addition.Inner.InnerMost.disp();
//
//		Addition.Inner.InnerMost i=new Addition(1,2).new Inner().new InnerMost();
//		i.eop();
//		

		S8 s8=new S8();
		s8.show();
		
//		S4.S5 s5=new S4.S5();
//		s5.show();
	}

}
class S1
{
	private int a;//instance variable or member variable
	S1(int a)
	{
		this.a=a;
	}
	class S2//member inner class
	{
		int b;
		S2(int b)
		{
			this.b=b;
		}
		void show()
		{
			System.out.println("Value of member variables "+a+" "+b);
		}
	}
	class S3//member inner class
	{
		int b;
		void show()
		{
			System.out.println("Value of member variables "+a+" "+b);
		}
	}
}

class S4
{
	int a=10;
	static class S5
	{
		int b=20;
		void show()
		{
			S4 s4=new S4();
			
			System.out.println(s4.a+" "+b);
		}
	}
}
//call show method of s5 inside main
class D7
{
	static int a;
}




/*
 *Nested class(Inner class) :
 *Member inner class
 *Local Inner class
 *Anonymous
 *
 *Static class
 *
 *
 *
 *
 *
 *
 *
 */

class Addition
{
	int num1,num2;
	Addition(int num1,int num2)
	{
		this.num1=num1;
		this.num2=num2;
	}
	class Inner
	{
		void add()
		{
			System.out.println("Output of addition is "+(num1+num2));
		}
		class InnerMost
		{
			static void disp()
			{
				System.out.println("addition completed");
			}
			void eop()
			{
					System.out.println("END OF PROGRAM");
			}
		}
		
	}
	static class Inner2
	{
		int i1;
		Inner2(int i1)
		{
			this.i1=i1;
		}
		void method()
		{
			System.out.println("Starting the program "+i1);
		}
	}
}
//local inner class
class S8
{
	void show()
	{
		int a;
		class S9
		{ 	
			int b;
			S9(int b)
			{
			
				this.b=b;
			}
			void disp()
			{
				System.out.println("The value for b "+b);
			}
		}
		System.out.println("Working with local class");
		S9 s9=new S9(34);
		s9.disp();		
	}
}



