package batch1;

public class Main27 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Java";
		System.out.println("Calculate length of string characters : "+str.length());
		System.out.println(str.concat(" Programming"));
		System.out.println(str);
		System.out.println(str.charAt(0));
		str=str.concat(" Programming");//Java Programming
		System.out.println(str.substring(2, 10));
		String username="nisha.jaiswal";
		String password="nisha@123";
		if(username.equalsIgnoreCase("NISha.JaiswAl"))
		{
			if(password.equals("NISHA@123"))
			{
				System.out.println("password Match found");
			}
			else 
			{
				System.out.println("Password does not match");
			}	
		}
		else
		{
			System.out.println("USername match not found");
		}
	String str1="Hello Learners We have started String now";
	//datatype arrname[]=new datatype[89];
	String data[]=str1.split(" ");//delimiter
	for(String d:data)//enhanced for loop
	{
		System.out.println(d);
	}
	//mutable
	char ch[]=str1.toCharArray();
	for(char d:ch)
	{
		System.out.print("["+d+"],");
	}
}
}
