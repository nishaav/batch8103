package com.classicenterprises.e_commerce;


//Synchronized block
public class MT4 {

	public static void main(String[] args) {
		
		MyResource1 r=new MyResource1();
		/*MyResource1 r1=new MyResource1();
		 MyResource1 r2=new MyResource1();
		MyThread11 m1=new MyThread11(r1);
		MyThread21 m2=new MyThread21(r1);
		MyThread31 m3=new MyThread31(r2);
		MyThread41 m4=new MyThread41(r2);
		
		m1.start();
		m2.start();
		m3.start();
		m4.start();
		 
		 
		 	*/
		MyThread11 m1=new MyThread11(r);
		MyThread21 m2=new MyThread21(r);
		m1.start();
		m2.start();
		
	}
}
class MyResource1
{
	void show(int n)
	{
		//start of block
		synchronized(this)
		{
			for(int i=1;i<=10;i++)
			{
				System.out.println(i*n);
				try
				{
					Thread.sleep(2000);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}		
		}
		//end of block
	}
}


class MyThread11 extends Thread
{
	MyResource1 r1;
	
	MyThread11(MyResource1 r1)
	{
		this.r1=r1;
	}
	public void run()
	{
		r1.show(10);
	}
}


class MyThread21 extends Thread
{
	MyResource1 r1;
	
	MyThread21(MyResource1 r1)
	{
		this.r1=r1;
	}
	public void run()
	{
		r1.show(2);
	}
}