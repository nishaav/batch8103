package com.classicenterprises.e_commerce;

public class MT2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Sample sample=new Sample();
			Thread1 thread1=new Thread1(sample);
			Thread2 thread2=new Thread2(sample);
			thread1.start();
			thread2.start();
		
	}

}
/*
 * Synchronization :is the capability to control access to the shared resource among multiple threads.
 * 
 * Advantage:
 * 1) To prevent thread interference.
 * 2) resource will be synchronized.
 * 3) avoids ambiguity and loss of data.
 * 4) implication of object monitor lock.
 * 
 * Disadvantage:
 * 1) The functionality can be a bit slower
 * 
 * 1) synchronized method
 * 2) synchronized block
 * 3) static synchronization
 * 
 */

class Sample
{
	synchronized void show(int n)
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println(Thread.currentThread().getName()+" : "+n*i);
			try
			{
				Thread.sleep(1500);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		
		}
	}
}

class Thread1 extends Thread
{
	Sample sample;
	Thread1(Sample sample)
	{
		this.sample=sample;
	}
	public void run()
	{
		sample.show(2);
	}

}

class Thread2 extends Thread
{
	Sample sample;
	Thread2(Sample sample)
	{
		this.sample=sample;
	}
	public void run()
	{
		sample.show(13);
		//code statement
	}

}



