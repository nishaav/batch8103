package com.classicenterprises.e_commerce;

import java.io.BufferedReader;
import java.io.FileReader;

public class App3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		try
		{
			FileReader fr=new FileReader("C:\\Users\\hp\\OneDrive\\Desktop\\demo.txt"); 
			BufferedReader br=new BufferedReader(fr);
			BufferedReader br1=new BufferedReader(new FileReader("C:\\Users\\hp\\OneDrive\\Desktop\\demo.txt"));
			int i=0;
    		while((i=br.read())!=-1)
    		{
    			System.out.println((char)i);
    		}
			String i1;
			while((i1=br1.readLine())!=null)
			{
				System.out.println(i1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
