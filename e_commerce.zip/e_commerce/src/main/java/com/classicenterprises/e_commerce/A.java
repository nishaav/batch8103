package com.classicenterprises.e_commerce;

import java.util.ArrayList;

public class A
{
	ArrayList<String> list1;

	public A(ArrayList<String> list1) {
		super();
		this.list1 = list1;
	}
	
	
}
