package com.classicenterprises.e_commerce;

import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	/*
    	 * File handling : files for reading or writing requiremnt
    	 * 
    	 * 
    	 * FMS : File Management System
    	 * File Handling
    	 */
    	
    	try(FileOutputStream fout=new FileOutputStream("C:\\Users\\hp\\OneDrive\\Desktop\\demo.txt");
    			FileInputStream fin=new FileInputStream("C:\\Users\\hp\\OneDrive\\Desktop\\demo.txt"))
    	{
    		//in case file does not exist, it will create a file else the file content will be overridden
    		//instance
    		//write mode
    	//Append Mode	  
//    		FileOutputStream fout=new FileOutputStream("C:\\Users\\hp\\OneDrive\\Desktop\\demo.txt",true);//instance
    		String str="-2";//data to be written
    		
    		//byte format-<>byte stream
    		//explicit conversion
    		byte b[]=str.getBytes();//conversion from String to byte
    		fout.write(-2);
    		fout.write(b);//writing data to the file
    		System.out.println("Data transferred successfully");
    		int i=0;
    		while((i=fin.read())!=-1)
    		{
    			System.out.println((char)i);
    		}
    		//fout.close();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		System.out.println("Unable to write");   		
    	}
    	
    }
}
