package com.classicenterprises.e_commerce;

public class LambdaExpression1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//lambda expression or anonymous function/methods
		
		/*
		 * parameter/argument list
		 * arrow operator
		 * method body
		 *
		 *
		 * functional interface
		 * -> is interface which can have only 1 abstract method for defining
		 * -> it can have other methods which are defined using static or default keyword
		 * -> SAM interfaces : SAM->Single Abstract Method Interfaces
		 * 
		 * Benefits :
		 * ->less line of code
		 * ->avoids unnecessary memory consumption.
		 * 
		 */
	
	//	int i=add(23,34);
//lambda expression1 
		I i=(a,b)->{return a+b;};
		
		
		
		int value=i.add(34, 56);
	
		System.out.println(value);
	
		I1 i1=(int a,int b)->a-b;
		System.out.println(i1.sub(23, 12));
		I2 i2=a->{			
			if(a%2==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		};
//		C c=(int a,int b)->a-b;
		System.out.println(i1.sub(23, 12));
		
		
		System.out.println(i2.evenOdd(34));
	
		I3 i3=(int a,int b)->{
			int max;//local variable inside a lambda expression
			if(a>b)
			{
				max=a;
			}
			else
			{
				max=b;
			}
				return max;
		};
		System.out.println(i3.highest(34, 46));
		
	
	
	}
	static int add(int x,int y)
	{
		return x+y;
	}
}
abstract class C
{
	abstract int add(int a,int b);
}
@FunctionalInterface
interface I
{
	int add(int a,int b);
}
@FunctionalInterface
interface I1
{
	int sub(int a,int b);
}
@FunctionalInterface
interface I2
{
	boolean evenOdd(int a);
}

@FunctionalInterface
interface I3
{
	int highest(int a,int b);
}