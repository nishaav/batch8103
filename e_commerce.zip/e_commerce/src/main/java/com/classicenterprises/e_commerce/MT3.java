package com.classicenterprises.e_commerce;

public class MT3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Sample2 sample=new Sample2();
			Thread21 thread1=new Thread21(sample);
			Thread22 thread2=new Thread22(sample);
			Sample2 sample2=new Sample2();//
			
			Thread23 thread3=new Thread23(sample2);
			Thread24 thread4=new Thread24(sample2);
			
			
			thread1.start();
			thread2.start();
			thread3.start();
			thread4.start();
		
	}

}

class Sample2
{
	synchronized static void show(int n)
	{
		//statements 
		//synchronized(this) //object reference/resource
			//{
			/*
			 * Why this is specified here within the parenthesis
			 * To acquire a lock on the current class instance.
			 * 
			 */
			for(int i=1;i<=5;i++)
			{
				System.out.println(Thread.currentThread().getName()+" : "+n*i);
				try
				{	
					Thread.sleep(1500);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
		
			}
			//}
	}
}

class Thread21 extends Thread
{
	Sample2 sample;
	Thread21(Sample2 sample)
	{
		this.sample=sample;
	}
	public void run()
	{
		sample.show(2);
	}

}

class Thread22 extends Thread
{
	Sample2 sample;
	Thread22(Sample2 sample)
	{
		this.sample=sample;
	}
	public void run()
	{
		sample.show(13);
		//code statement
	}
}



class Thread23 extends Thread
{
	Sample2 sample;
	Thread23(Sample2 sample)
	{
		this.sample=sample;
	}
	public void run()
	{
		sample.show(17);
	}

}

class Thread24 extends Thread
{
	Sample2 sample;
	Thread24(Sample2 sample)
	{
		this.sample=sample;
	}
	public void run()
	{
		sample.show(21);
		//code statement
	}
}



