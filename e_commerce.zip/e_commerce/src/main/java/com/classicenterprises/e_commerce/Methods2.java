package com.classicenterprises.e_commerce;

import java.util.ArrayList;
public class Methods2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Collection to an Array
		
		ArrayList<Training> al=new ArrayList<>();
		al.add(new Training(1,"Nitish"));
		al.add(new Training(2,"Naman"));
		al.add(new Training(3,"Aman"));
		al.add(new Training(4,"Priyansh"));
		al.add(new Training(5,"Shivaansh"));
		
		Training[] ar=al.toArray(new Training[al.size()]);
		
		for(Training str:ar)
		{
			System.out.println(str.id+" "+str.name);
		}
	
	}

}

class Training
{
	int id;
	String name;
	
	Training(int id,String name){
		this.id=id;
		this.name=name;
	}
	
	
}