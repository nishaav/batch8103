package com.classicenterprises.e_commerce;

import java.util.Arrays;
import java.util.List;

public class Methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] c= {"A","B","C"};
		List list=Arrays.asList(c);

		int ar[]= {23,34,65};
		List list1=Arrays.asList(ar);
		
		System.out.println(list);

		System.out.println(list1.toString());
	}

}
