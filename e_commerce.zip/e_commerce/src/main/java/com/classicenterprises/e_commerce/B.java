package com.classicenterprises.e_commerce;

import java.util.ArrayList;

public class B
{
	ArrayList<String> list2;

	public B(ArrayList<String> list2) {
		super();
		this.list2 = list2;
	}
	
	
}
