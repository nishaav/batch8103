package com.classicenterprises.e_commerce;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MergingOfList 
{
	
	public static void main(String[] args) {
		ArrayList<String> al1=new ArrayList<>();
		al1.add("A");
		al1.add("B");
		al1.add("C");
		al1.add("D");
		al1.add("E");
		ArrayList<String> al2=new ArrayList<>();
		al2.add("F");
		al2.add("G");
		al2.add("H");
		al2.add("I");
		al2.add("J");
		A a=new A(al1);
		B b=new B(al2);
		System.out.println(a.list1);
		System.out.println(b.list2);
		ArrayList<String> mergedList=new ArrayList<>();
		//adding list2 elements in list1
		mergedList.addAll(a.list1);
		mergedList.addAll(b.list2);
		System.out.println(mergedList);	
		
		//map 
		List<Integer> numbers=Arrays.asList(1,2,3,4,5);
		//type safety
		
		List<Integer> sq=(ArrayList<Integer>)numbers.stream().map((i)->i*i).collect(Collectors.toList());
		
		
		ArrayList<Employee> empList=new ArrayList<>();
		empList.add(new Employee(1,"Nisha",45000));
		empList.add(new Employee(2,"Nishant",40000));
		empList.add(new Employee(3,"Naman",42000));
		empList.add(new Employee(4,"Disha",48000));
		empList.add(new Employee(5,"Dishant",32000));
		empList.add(new Employee(6,"Daman",70000));
		
		ArrayList<Employee> empList1=new ArrayList<>();
		
		for(Employee e: empList)
		{
			if(e.salary>=45000)
			{
				empList1.add(e);
			}
		}
		List<Employee> empList2=empList.stream().filter(e->e.salary>=45000).collect(Collectors.toList());
		System.out.println(empList2);
		List<String> empSalaryList=empList.stream().filter(e->e.salary>=45000).map(e->e.name).collect(Collectors.toList());
		System.out.println(empSalaryList);
		
		empList.stream().filter(emp->emp.salary>45000).limit(1).forEach(e->System.out.println(e.id+" "+e.name));
		
		long size=empList.stream().count();
		
		long count=empList.stream().filter(emp->emp.salary>45000).count();
		
		Employee emp=empList.stream().max((e1,e2)->e1.salary>e2.salary?1:-1).get();
		//it returns the last element from the collection.
		System.out.println(emp);
		
		Employee emp1=empList.stream().min((e1,e2)->e1.salary>e2.salary?1:-1).get();
		//it returns the first element from the collection.
		System.out.println(emp1);
		
		//reduce() will take multiple elements as input and will provide a single output 
		//summing,average,percentage
		
		
		double totalSalary=empList.stream().map(e->e.salary).reduce(0, (sum,salary)->sum+salary);
		
		System.out.println(totalSalary);
	
	}
}
class Employee
{
	int id;
	String name;
	int salary;
	public Employee(int id, String name, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public String toString()
	{
		return id+" "+name+" "+salary;
	}

}