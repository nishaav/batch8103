package com.classicenterprises.e_commerce;

import java.io.FileWriter;

public class App2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try(FileWriter fw=new FileWriter("C:\\Users\\hp\\OneDrive\\Desktop\\dummy.txt"))
		{
			//char stream
			fw.write("Hey I am learning FileWriter");
			
			System.out.println("End Of File!!");
			
			//BufferedReader : read mode :
			//FileReader
			//increases the performance & efficiency of program 
			//BufferedWriter :
			//FileWriter
			
			
		}
		catch(Exception e)
		{
			
		}
	}

}
