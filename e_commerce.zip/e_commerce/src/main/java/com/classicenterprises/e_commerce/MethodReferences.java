package com.classicenterprises.e_commerce;

public class MethodReferences {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		D d=Learner::print;//
	//	d.show();
		
		
	}

	
	
}

@FunctionalInterface
interface D
{
	void show();
}

class Learner
{
	static void print()
	{
		System.out.println("Method References");
	}
}