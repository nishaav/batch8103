package com.capgemini.vehicleinsurancesystem;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class LearnerTest {

	@Test
	public void testEligible()
	{
		Learner learner=new Learner();
		learner.age=20;
		assertTrue(learner.eligible());
		
	}
	@Test
	public void testEligible1()
	{
		Learner learner=new Learner();
		learner.age=20;
		assertFalse(learner.eligible());
		
	}
		
}


