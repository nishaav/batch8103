package com.capgemini.vehicleinsurancesystem;

import java.io.Console;
import java.util.Scanner;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.JUnitCore;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {	
//    	Result result=JUnitCore.runClasses(Testing.class);
//    	System.out.println(result.getFailureCount());
//    	System.out.println(result.getIgnoreCount());
//    	for(Failure failure:result.getFailures())
//    	{
//    		System.out.println(failure.toString());
//    	}
//    	System.out.println(result.wasSuccessful());
    	
////        Scanner scanner=new Scanner(System.in);
////        
////        System.out.println("Enter your id : ");
////        
////        int id=scanner.nextInt();
////        
////        scanner.nextLine();//blank statement to handle the new line character generated after nextInt()
////        System.out.println("Enter your name : ");
////        
////        String name=scanner.nextLine();
////        
////        System.out.println("The details are : \nID : "+id+"\nName : "+name);
//    	
//        
//        Console con = System.console();   
//        
//        if(con==null)
//        {
//        	System.out.println("No console ");
//        	return;
//        }
//        System.out.println("Enter the password: ");   
//        char[] ch=con.readPassword();   
//        String pass = String.valueOf(ch);   
//        System.out.println("Password is: " + pass); 
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    }
    
   public int add(int a,int b)
   {
	   return a+b;
   }
    
   public boolean evenOdd(int a)
   {
	   if(a%2==0)
	   {
		   return true;
	   }
	   else
	   {
		   return false;
	   }
   }
   
   
   
   
}
//89 \nENter: new line character

// \n