package com.classicenterprises.DesignPatterns;

public class IteratorPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coll coll=new Coll();
		
//		for(Iterator itr=coll.getIterator();itr.hasNext();)
//		{
//				System.out.println(itr.next());
//		}

		//Iterator itr=al.iterator();
		
		Iterator itr1=coll.getIterator();
		while(itr1.hasNext())
		{
			System.out.println(itr1.next());
		}
	}
}

interface Iterator
{
	public boolean hasNext();
	public Object next();// to visit all kinds of collection whether a wrapper class or user defined class
}


interface Container
{
	public Iterator getIterator();
}

//class implementing Container interface
class Coll implements Container
{
	String info[]={"Data1","Data2","Data3","Data4","Data5"};

	@Override
	public Iterator getIterator() {//behavior
		return new CollImpl();//Upcasting
	
	}
	private class CollImpl implements Iterator
	{
		int i;
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			if(i<info.length)
			{
				return true;
			}
			return false;
		}

		@Override
		public Object next() {
			// TODO Auto-generated method stub
			if(this.hasNext())
			{
				return info[i++];
			}
			return null;
		}
		
	}
	
}






/*Behavioural Design Pattern
 * 
 * Iterator Pattern : 
 * -> to access the elements of an aggregate object in a sequence without exposing the implementation
 * -> Cursor
 * 
 * -> java.util.Iterator interface has been designed by the implementation of Iterator Design Pattern
 * 
 * Advantage :
 * ->helps in traversing the collection  in a simple way.
 * ->useful when multiple traversal need to be supported in a collection.
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * Iterator->Cursor
 */
//Iterator 
