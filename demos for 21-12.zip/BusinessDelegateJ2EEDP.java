package com.classicenterprises.DesignPatterns;
//Business Delegate
public class BusinessDelegateJ2EEDP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BusinessDelegate businessDelegate=new BusinessDelegate();
		businessDelegate.setServiceType("Business1");
		Client client=new Client(businessDelegate);
		client.display();
		
		businessDelegate.setServiceType("Business2");
		client.display();
	}

}


//DAO : Data Access Object 
interface BusinessService
{
	void process();
}

class Business1 implements BusinessService
{
	public void process()
	{
		System.out.println("Handling Business 1");
	}
}

class Business2 implements BusinessService
{
	public void process()
	{
		System.out.println("Handling Business 2");
	}
}

//Lookup service

class BusinessLookUp
{
	public BusinessService getBusinessService(String serviceType)
	{
		if(serviceType.equalsIgnoreCase("Business1"))
		{
			return new Business1();
		}
		else if(serviceType.equalsIgnoreCase("Business2"))
		{
			return new Business2();
		}
		else
		{
			return null;
		}
	}
}

class BusinessDelegate 
{
	private BusinessLookUp lookUpService=new BusinessLookUp();
	private BusinessService businessService;
	private String serviceType;
	public void setServiceType(String serviceType) {
		
		this.serviceType = serviceType;
	}
	
	void show()
	{
		businessService=lookUpService.getBusinessService(serviceType);
		businessService.process();
	}
	
}

//Client

class Client
{
	BusinessDelegate businessDelegate;
	Client(BusinessDelegate businessDelegate)
	{
		this.businessDelegate=businessDelegate;
	}
	void display()
	{
		businessDelegate.show();
	}
}

/*
 * Business Delegate Pattern :
 * the components required
 * 1)Client : front end
 * 2)Business Delegate : which specifies a single entry point in the application to provide access to the
 * service methods
 * 3)Business Service Interface : to provide actual business implementation by implementing
 * on a concrete class
 * 4)Lookup Service : the instance will be responsible to get the business implementation accessible
 * 
 * 
 * 
 * 
 *
 */

