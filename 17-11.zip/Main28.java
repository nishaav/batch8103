package batch1;

public class Main28 {

	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		String ref1="Java";
//		String ref2="java";
//				
//		System.out.println(ref1.compareTo(ref2));//ref1-ref2 74-106=-32
//		System.out.println(ref2.compareTo(ref1));//ref2-ref1 106-74=32
//		System.out.println(ref1.compareTo("Java"));//ref1-Java 0
//		
//		System.out.println(ref1.compareToIgnoreCase(ref2));//ref1-ref2 74-106=-32
//		System.out.println(ref2.compareToIgnoreCase(ref1));//ref2-ref1 106-74=32
//		System.out.println(ref1.compareToIgnoreCase(" Java"));//ref1-Java 0
//		
//		System.out.println("Aakash".compareTo("Aman"));
//		System.out.println("Aakash".compareToIgnoreCase("Aman"));
//		
//		//Aakash   Aman
//		//97 109
//		
//		
//		String ref3="Programming";
//		String ref4="Programming";
//		String ref5=new String("Programming");
//		String ref6=new String("Programming");
//		
//		System.out.println(ref3==ref4);//true
//		System.out.println(ref3==ref5);//true
//		System.out.println(ref4==ref5);//true
//		System.out.println(ref5==ref6);//true
//		//Methods of String class
//		System.out.println("Methods");
//		System.out.println(ref3.contains("gram"));
//		System.out.println(ref3.contains("Gram"));
//		
//		System.out.println(ref3.indexOf("G"));
//		System.out.println(ref3.indexOf("g"));
//		System.out.println(ref3.lastIndexOf("G"));
//		System.out.println(ref3.lastIndexOf("g"));
//		System.out.println(ref3.toUpperCase());
//		System.out.println(ref3.toLowerCase());
//		System.out.println(ref3.endsWith("g"));
//		System.out.println(ref3.endsWith("G"));
//		System.out.println(ref3.startsWith("P"));
//		System.out.println(ref3.startsWith("p"));
//		
//		
//		String ref8=new String("Java").intern();
//		String ref9=new String("Java").intern();
//		System.out.println(ref8==ref9);
//		
//		
//		System.out.println(ref3.replace('m','n'));
//		System.out.println(ref3.replaceAll("ming","s"));
//		
//		System.out.println("["+" Java Programs ".trim()+"]");
//		
//		System.out.println(ref3.replaceFirst("r", "m"));
//	
//		String ref11 = new String( "Programming") ;
//	        System.out.println(ref11.replace(ref11.charAt(2), 'S'));
//
//		
		//replaceFirst
		//Programming
		//replaceSecond
		//WAP to replace the second occurence of character with any other
	        
	        //programming
	        //String ref1=new String("Programming");
			// TODO Auto-generated method stub
//			String ref1=new String("Programming");
//			String ref2=ref1.replaceFirst("r", "m");
//			System.out.println(ref2);
//			System.out.println(ref2.replaceFirst("r", "m"));
//			
//			//

			Main28 main=new Main28();
			String value=main.replaceSecond("Programming", "m", "n");
			System.out.println("After removing second occurence : "+value);
		
	}
	String replaceSecond(String inputString,String replaceString,String replaceWith)
	{
		String ref1=inputString;
		//System.out.println("ref1 : "+ref1);
		int index=ref1.indexOf(replaceString);
		String str=ref1.substring(0,index+1);
		String str1=ref1.substring(index+1);
		//System.out.println("str : "+str);
		//System.out.println("str1 : "+str1);
		str1=str1.replaceFirst(replaceString, replaceWith);
		return str.concat(str1);
	}
}
//enum 