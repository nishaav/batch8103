package streamDemos;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.Map;
public class Stream2 {
	// Student class is defined in Stream 1
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> list=new ArrayList<>();//Upcasting or dynamic method dispatching
		
		list.add(new Student(1,"Niharika",23));
		list.add(new Student(2,"Neha",24));
		list.add(new Student(3,"Divya",24));
		list.add(new Student(4,"Piyali",26));
		list.add(new Student(5,"Vaishali",27));
		
		List<Integer> ages=list.stream()
						.filter(s->s.age>24)//filtering data  conditional predicate
						.map(s->s.age)// fetching the data satisfied by the conditional predicate
						.collect(Collectors.toList());// collecting the response as list.
		
		// Code by implementing the stream api functions become more maintained and more optimized.
		// it will be executing in a faster span.
		System.out.println(ages);
		
		// Convert the list into a Set
		Set<Integer> set1=list.stream()
				.filter(s->s.age>24)//filtering data  conditional predicate
				.map(s->s.age)// fetching the data satisfied by the conditional predicate
				.collect(Collectors.toSet());// collecting the response as list.
		
		System.out.println(set1);
		
		Set<Integer> set2=list.stream()
				.map(s->s.age)// fetching the data satisfied by the conditional predicate
				.collect(Collectors.toSet());// collecting the response as list.
		System.out.println(set2);
		
	// Map interface : works on the key value pair which is referred as SET

		Map<Integer,String> map1=list.stream()
							.collect(Collectors.toMap(s->s.id, s->s.name));	
	// map() method is not grouped while converting the collection into a Map type of reference as map () will
		//restrict it to fetch only a single element and in case of casting into a map reference, we need 
		// atleast 2 elements one serving as a key and other serving as a value.
		System.out.println(map1);
		
	}
}
