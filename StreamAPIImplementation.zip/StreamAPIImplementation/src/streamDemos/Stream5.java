package streamDemos;

import java.util.*;
import java.util.stream.Collectors;
public class Stream5 {

	public static void main(String[] args) {

		//how to refer the methods of a class : ensure method should be of a specific return type
		// based on the return type of method, we would make the type of collection.
		List<User> list=new ArrayList<>();
		
		list.add(new User(1,"Nisha",27));
		list.add(new User(2,"Niharika",24));
		list.add(new User(3,"Geetanjali",23));
		list.add(new User(4,"Shreya",21));
		list.add(new User(5,"Piyali",26));
		
		List<Integer> li=list.stream()
						.filter(u->u.age>25)
						.map(User::getAge) // fetching the age by referring the getter method of the class.
						.collect(Collectors.toList());
		System.out.println(li);
		
		List<String> li1=list.stream()
				.filter(u->u.age>25)
				.map(User::getName) // fetching the age by referring the getter method of the class.
				.collect(Collectors.toList());
System.out.println(li);
// The method which you are trying to call should be of a specific return type.

		
		List<Integer> l=list.stream()
				.map(User::getAge) // fetching the age by referring the getter method of the class.
				.collect(Collectors.toList());
		System.out.println(l);

		
	}

}

class User
{
	int id;
	String name;
	int age;
	
	public User(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	
	
	
}