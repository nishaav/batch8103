package streamDemos;

import java.util.ArrayList;
import java.util.List;

public class Stream1 {
/*
 *  Stream API : 
 *  
 *-> Java stream is a new package added in Java 8 
 *-> path of package is java.util.stream
 *-> It is used to work with collection of objects. : collections,arrays. I/O Channel
 *-> Stream is referred as a sequence of objects 
 *-> It is not a data structure to store the elements.
 *-> It is used as a way to convey the objects from the source to destination and can perform the computation/
 * manipulation by using the methods available to be pipelined to produce the desired output. 
 * -> Stream is lazy and evaluates the code when required.
 * -> it works on the Lambda Expressions as Stream is an interface.
 * 
 * 
 * arrow functions
 * 
 * Lambda-> Functional Interfaces : The interface which stores only 1 method.
 * 
 * Select statement : 
 * Table 
 * 
 * select concat(first_name," ",last_name) as "Student Name" from student
 * 
 * 
 * System.out : OutputStream
 * System.in  : InputStream
 * 
 * Stream : 
 * 
 * int a;(RAM)
 * 
 * CONSOLE : 
 * Scanner sc=new Scanner(System.in);
 */
	public static void main(String[] args) {
		List<Student> list=new ArrayList<>();//Upcasting or dynamic method dispatching
		
		list.add(new Student(1,"Niharika",23));
		list.add(new Student(2,"Neha",24));
		list.add(new Student(3,"Divya",25));
		list.add(new Student(4,"Piyali",26));
		list.add(new Student(5,"Vaishali",27));
		
		List<Integer> li=new ArrayList<>();
		for(Student student:list)
		{
			if(student.age>24)
			{
				li.add(student.age);
			}
		}
		System.out.println(li);

	}

}

class Student
{
	int id;
	String name;
	int age;
	public Student(int id, String name, int age) {
		this.id = id;
		this.name = name;
		this.age = age;
	}
}

