package streamDemos;

import java.util.ArrayList;
import java.util.List;

public class Stream3 {
// Student class is defined in Stream 1
	public static void main(String[] args) {
		// Iterating over the elements
List<Student> list=new ArrayList<>();//Upcasting or dynamic method dispatching
		
		list.add(new Student(1,"Niharika",23));
		list.add(new Student(2,"Neha",24));
		list.add(new Student(3,"Divya",25));
		list.add(new Student(4,"Piyali",26));
		list.add(new Student(5,"Vaishali",27));
		
		list.stream()// providing a sequence of stream of objects
			//.filter(s->s.age>24)//filtering the data
			.forEach(s->System.out.println(s.name+" "+s.id+" "+s.age));// iterating over the elements of the collections

	}

}
