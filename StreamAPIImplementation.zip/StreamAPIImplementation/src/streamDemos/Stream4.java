package streamDemos;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Stream4 {

	public static void main(String[] args) {
	
		// generate single output by summarizes/adding the multiple inputs :
		List<Student> list=new ArrayList<>();//Upcasting or dynamic method dispatching
		
		
		list.add(new Student(3,"Divya",25));
		list.add(new Student(4,"Piyali",26));
		list.add(new Student(5,"Vaishali",27));
		list.add(new Student(1,"Niharika",23));
		list.add(new Student(2,"Neha",24));
	//option 1	
		Integer addAge=list.stream()
							.map(s->s.age)
							.reduce(0, (sum,age)->sum+age);// accumulator--> used to accumulate the values of the provided field.
		System.out.println(addAge);
	// option 2 using Collector's accumulating method
		//calculating the average
		double avgage=list.stream()
						.collect(Collectors.averagingDouble(s->s.age));
		System.out.println(avgage);
		
		//calculating the sum by using Collector's method
		double sumage=list.stream()
				.collect(Collectors.summingDouble(s->s.age));
			System.out.println(sumage);
		
		// find the MIN 
		Student studentA=list.stream().min((student1,student2)->student1.age>student2.age?1:-1).get();	
		System.out.println(studentA.age);
		
		// find the MAX 
				Student studentB=list.stream().max((student1,student2)->student1.age>student2.age?1:-1).get();	
				System.out.println(studentB.age);
				
		//count the number of elements		
				
			long count=list.stream()
							//.filter(s->s.age>25)
					      .count();
			System.out.println(count);
		
			
			
	}

}
