module StreamAPIImplementation {
}