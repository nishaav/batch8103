package com.classicenterprises.e_commerce;

public class MT1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Thread t1=new Thread();//user defined thread
//		Thread t2=Thread.currentThread();//currently executing thread
//		
//		System.out.println(t1.getName());
//		System.out.println(t2.getName());
//		
//		System.out.println(t1.getPriority());
//		System.out.println(t2.getPriority());
//		
//		System.out.println(t1.getState());
//		System.out.println(t2.getState());
//		
//		System.out.println(t1.getId());
//		System.out.println(t2.getId());
//		
//		System.out.println(t1.getThreadGroup());
//		System.out.println(t2.getThreadGroup());
//	
//		System.out.println(t1.MIN_PRIORITY);
//		System.out.println(t1.MAX_PRIORITY);
//		System.out.println(t1.NORM_PRIORITY);
//	
//		System.out.println(t2.MIN_PRIORITY);
//		System.out.println(t2.MAX_PRIORITY);
//		System.out.println(t2.NORM_PRIORITY);
//		Thread t1=new Thread();
//		t1.start();
//		
		MyThread1 myThread=new MyThread1();
		myThread.setName("One");
		myThread.start();

		Runnable mythread2=new MyThread2();
		Thread t2=new Thread(mythread2);
		t2.setName("Two");
		t2.start();
	}
}


class MyThread2 implements Runnable
{
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println("Thread : "+Thread.currentThread().getName()+" Output : "+i);
			try
			{
				Thread.sleep(3200);//millisecond 
			}
			catch(Exception e)
			{	
				e.printStackTrace();
			}
		}		
	}
}

class MyThread1 extends Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("Thread : "+Thread.currentThread().getName()+" Output : "+i);
			try
			{
				Thread.sleep(3200);//millisecond 
			}
			catch(Exception e)
			{	
				e.printStackTrace();
			}
		}
	}
}






