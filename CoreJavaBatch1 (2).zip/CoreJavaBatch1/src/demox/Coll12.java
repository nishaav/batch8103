//package demox;
//
//import java.util.LinkedHashMap;
//
//public class Coll12 {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		LinkedHashMap<Integer,Student> lhm=new LinkedHashMap<>();
//		//insert objects lhm collection and print the output
//	
//		
//		
//	}
//
//}
//class Address
//{
//	String hno;
//	int pinCode;
//	String city;
//	String state;
//	public Address(String hno, int pinCode, String city, String state) {
//		super();
//		this.hno = hno;
//		this.pinCode = pinCode;
//		this.city = city;
//		this.state = state;
//	}
//}
//class Student
//{
//	int id;
//	String name;
//	Address add;
//	public Student(int id, String name, Address add) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.add = add;
//	}	
//}

//Encapsulation : task
//maven and junit
/*
 * 
 * 
 * 
 * 
 * 
 * 
 */












