package demox;

import java.util.ArrayList;

public class Coll7 {

	public static void main(String[] args) {
	
		
		
		ArrayList<Integer> i1=new ArrayList<>();
		i1.add(23);
		i1.add(2);
		i1.add(3);
		i1.add(34);
		i1.add(54);
		i1.add(10);
		i1.add(8);
		i1.add(82);
		i1.add(19);
		i1.add(9);
	//Integer->int
		System.out.println(i1);
		System.out.println(i1.remove((Integer)3));
		System.out.println(i1);

	
	}

}




