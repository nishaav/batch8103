package com.capgemini.vehicleinsurancesystem;


public class Learner {

	int id;
	String name;
	int age;

	
	
	boolean eligible()
	{
		if(age>18)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
