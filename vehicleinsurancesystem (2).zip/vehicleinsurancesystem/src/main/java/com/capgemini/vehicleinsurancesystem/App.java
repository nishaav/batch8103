package com.capgemini.vehicleinsurancesystem;

import java.io.Console;
import java.util.Scanner;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.JUnitCore;
import java.util.*;
/**
 * Hello world!
 *
 */
class Question
{
	String questionStatement;
	Answer ans;
	String correctAnswer;
	Question(String questionStatement,Answer ans,String correctAns)
	{
		this.questionStatement=questionStatement;
		this.ans=ans;
		this.correctAnswer=correctAnswer;
	}
	public String toString()
	{
		return questionStatement+"\n"+ans;
	}
}

class Answer
{
	List<String> answerList;
	
	Answer(List<String> answerList)
	{
		this.answerList=answerList;
	}
	public String toString()
	{
		String response="";

		for(String str:answerList)
		{
			response=str+"\n";
		}
		return response;
	}
	
}

public class App 
{
    public static void main( String[] args )
    {	
    	
    	List<Question> list=new ArrayList<>();
    	List<String> answerList1=new ArrayList<>();
    	answerList1.add("It is a programming language");

    	Answer answer=new Answer(answerList1);
    	
    	list.add(new Question("What is java",answer,"A"));
       	list.add(new Question("What is OOP",answer,"B"));
       	list.add(new Question("What is Hibernate",answer,"A"));
       	list.add(new Question("What is SpringBoot",answer,"B"));
       	list.add(new Question("What is Spring AOP",answer,"D"));
           	
    	Scanner scanner=new Scanner(System.in);
    	char ch;
    	int num=0;
    	do
    	{
    		System.out.println(list.get(num));
    		ch=scanner.next().toUpperCase().charAt(0);
    		num++;
    		//logic for verifying the option and calculating the marks
    		//in case user gives other options, then 
    	}while(ch=='A' ||ch=='B'||ch=='C'||ch=='D');
    	
    	
//    	Burger burger=new Burger();
//    	burger.createList();
    }
    
   public int add(int a,int b)
   {
	   return a+b;
   }
    
   public boolean evenOdd(int a)
   {
	   if(a%2==0)
	   {
		   return true;
	   }
	   else
	   {
		   return false;
	   }
   }
   
   
   
   
}
//89 \nENter: new line character

// \n