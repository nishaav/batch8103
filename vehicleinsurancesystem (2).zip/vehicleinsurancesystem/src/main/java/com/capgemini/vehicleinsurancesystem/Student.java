package com.capgemini.vehicleinsurancesystem;

public class Student {

}
