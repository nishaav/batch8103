package com.capgemini.vehicleinsurancesystem;

public class Burger {

	int burgerPrice;
	String burgerType;
	
	void createList()
	{
		System.out.println("Burger List");
		
	}
	
}
