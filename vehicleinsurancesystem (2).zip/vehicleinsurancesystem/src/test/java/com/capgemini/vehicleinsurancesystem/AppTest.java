package com.capgemini.vehicleinsurancesystem;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite.SuiteClasses;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
//    @Test
//    public void shouldAnswerWithTrue()
//    {
//        assertTrue( true );
//    }
	App app;
	
	@Before
	public void createInstance()
	{
		System.out.println("Checking start");
		app=new App();
	}

	@BeforeClass
	public static void atTheBeginning()
	{
		System.out.println("Testing Started");
	}
	
	@AfterClass
	public static void atTheEnd()
	{
		System.out.println("Testing Ends");
	}
	
	@After
	public void afterInstance()
	{
		System.out.println("End of Test case");
	}
	
	@Test// test case and executes
	public void addTest()
	{
		int result=app.add(34, 2);
		assertEquals(36,result);
	}

	@Test// test case and executes
	public void addTestN()
	{
		int result=app.add(34, 2);
		assertNotEquals(36,result);
	}
	
	@Test
	public void check()
	{
		int ar[]=new int[]{2,3};
		int ar1[]=new int[]{2,4};
		assertArrayEquals(ar,ar1);
		
		
	}
	
	
    /*
     *
     * After : in case any logic or code needs to  be executed after the execution of each test case
     * AfterClass : in case any logic or code needs to  be executed after the execution of all the test case 
     * Before : in case any logic or code needs to  be executed before the execution of each test case
     * BeforeClass : in case any logic or code needs to  be executed before the execution of all the test case
     * 
     * 
     * 
     * 
     */
    
    
    @Ignore
    @Test// test case and executes
   	public void addTest1()
   	{
   		int result=app.add(30, 2);
   		assertEquals(36,result);
   	}
    @Test// test case and executes
   	public void addTest2()
   	{
   		boolean result=app.evenOdd(23);
   		assertTrue(result);
   	}
    @Test
    public void testEvenOdd()
    {
    	boolean result=app.evenOdd(23);
   		assertFalse(result);	
    }
    String str;
    
    @Ignore
    @Test
    public void testCode()
    {
    	assertNotNull(str);
    	//assertNull(str);
    }
    
    @Test
    public void testAssertSame()
    {
    	String s1=new String("Java");
    	String s2=new String("Java");
    	
    	assertNotSame(s1,s2);//compares the references not the value hold by the instance
    	
    }
    
}
