package com.cg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.entity.Learner;


@Repository
public interface LearnerRepository extends CrudRepository<Learner, Integer> {
	
	 
}
//repository : 
/*
 * DAO : 
 * 
 * 
 * 
 * 
repository is to define all the possible methods which may be required to interact with Learner table

all the possible methods for interacting with the database esp
*/
