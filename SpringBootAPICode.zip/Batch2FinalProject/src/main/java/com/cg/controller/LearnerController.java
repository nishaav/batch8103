package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Learner;
import com.cg.service.LearnerService;
//frontController------>Handler Mapping----->frontController------>RestController---->Handler Method--->Service--->Repository---->Database
//API 
//json or XML
@RestController
//CORS policy violation
@CrossOrigin(origins = "http://localhost:8080")//to allow the indirect requests from different servers
public class LearnerController 
{
	@Autowired
	private LearnerService learnerService;
	
	@GetMapping("/springData/learners")
	public List<Learner> fetchLearnerDetails()//handler method
	{
		return learnerService.fetchLearnerList();
	}
	@GetMapping("/springData/learner/{uid}")
	public Learner fetchLearnerDetail(@PathVariable("uid") int learnerId)//handler method
	{
		return learnerService.fetchLearner(learnerId);
	}
	@DeleteMapping("/springData/learners/{id}")
	public boolean deleteLearnerById(@PathVariable("id") int learnerId)
	{
		return learnerService.deleteLearnerById(learnerId);
	}
	@PostMapping("/springData/learners")
	public Learner saveLearner(@RequestBody Learner learner)
	{
		return learnerService.saveLearner(learner);
	}
	@PutMapping("/springData/learners/{id}")
	public Learner updateLearner(@RequestBody Learner learner,@PathVariable("id") int learnerId)
	{
		return learnerService.updateLearner(learner, learnerId);
	}	
}
/*
 *Get ->fetching the data from the database
 *@GetMapping
 * 
 *Post->inserting the data to the table of the database
 *@PostMapping
 *
 *Put->updating the data of the table of the database
 *@PutMapping
 *
 *Delete->delete the data of the table of the database
 *@DeleteMapping
 */